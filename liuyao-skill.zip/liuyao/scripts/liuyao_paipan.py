#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
六爻排盘器（纳甲筮法排盘）

根据六次摇卦结果（或直接给本卦/变卦名）+ 月建地支 + 日柱干支，
输出完整排盘：卦宫、世应、纳甲干支、六亲、六神、旬空、月破、日冲、伏神提示、动变。

用法示例：
  # 方式一：六次摇卦结果（自下而上，老阳=三背、老阴=无背、少阳=一背、少阴=二背）
  python3 liuyao_paipan.py --throws 少阳 少阳 老阴 少阳 少阳 少阳 --day 庚申 --month 卯

  # 方式二：直接给卦名（变卦可省，无动爻则为静卦）
  python3 liuyao_paipan.py --hexagram 泽山咸 --bian 泽地萃 --day 庚申 --month 卯

  # 只需排盘不输入日月时，六神/旬空/月破等留空提示
  python3 liuyao_paipan.py --hexagram 天地否

说明：
- 六亲以本卦卦宫五行为"我"定（变卦六亲也按本卦卦宫定）。
- 世应按歌诀："天同二世天变五，地同四世地变初，人同游魂世居四，人变归魂世在三，全同六世全变三"。
- 卦宫：归魂卦取内卦；世在4/5爻取内卦阴阳互变；其余取外卦。
- 旬空以日柱定（六甲旬空），月建年建旬空力量小、不作主。
- 日冲只列关系，暗动/日破需结合爻之旺衰由解卦人判断。
"""

import argparse
import re
import sys

# ---------------------------------------------------------------- 基础表

GAN = "甲乙丙丁戊己庚辛壬癸"
ZHI = "子丑寅卯辰巳午未申酉戌亥"

ZHI_WX = {"子": "水", "丑": "土", "寅": "木", "卯": "木", "辰": "土", "巳": "火",
          "午": "火", "未": "土", "申": "金", "酉": "金", "戌": "土", "亥": "水"}
ZHI_YAO_YINYANG = {"子": "阳", "丑": "阴", "寅": "阳", "卯": "阴", "辰": "阳", "巳": "阴",
                   "午": "阳", "未": "阴", "申": "阳", "酉": "阴", "戌": "阳", "亥": "阴"}
LIUCHONG = {"子": "午", "丑": "未", "寅": "申", "卯": "酉", "辰": "戌", "巳": "亥",
            "午": "子", "未": "丑", "申": "寅", "酉": "卯", "戌": "辰", "亥": "巳"}

# 八纯卦：上/下卦三爻干支（初→上）。顺序：乾 坎 艮 震 巽 离 坤 兑
BAGUA = {
    "乾": {"wx": "金", "yin": "阳", "nei": ["甲子", "甲寅", "甲辰"], "wai": ["壬午", "壬申", "壬戌"]},
    "坎": {"wx": "水", "yin": "阳", "nei": ["戊寅", "戊辰", "戊午"], "wai": ["戊申", "戊戌", "戊子"]},
    "艮": {"wx": "土", "yin": "阳", "nei": ["丙辰", "丙午", "丙申"], "wai": ["丙戌", "丙子", "丙寅"]},
    "震": {"wx": "木", "yin": "阳", "nei": ["庚子", "庚寅", "庚辰"], "wai": ["庚午", "庚申", "庚戌"]},
    "巽": {"wx": "木", "yin": "阴", "nei": ["辛丑", "辛亥", "辛酉"], "wai": ["辛未", "辛巳", "辛卯"]},
    "离": {"wx": "火", "yin": "阴", "nei": ["己卯", "己丑", "己亥"], "wai": ["己酉", "己未", "己巳"]},
    "坤": {"wx": "土", "yin": "阴", "nei": ["乙未", "乙巳", "乙卯"], "wai": ["癸丑", "癸亥", "癸酉"]},
    "兑": {"wx": "金", "yin": "阴", "nei": ["丁巳", "丁卯", "丁丑"], "wai": ["丁亥", "丁酉", "丁未"]},
}

# 阴阳互变（用于卦宫：内卦变）
FAN = {"乾": "坤", "坤": "乾", "兑": "艮", "艮": "兑", "离": "坎", "坎": "离", "震": "巽", "巽": "震"}

# 八卦爻象（自下而上）：1阳 0阴
GUA_YAO = {"乾": [1, 1, 1], "兑": [1, 1, 0], "离": [1, 0, 1], "震": [1, 0, 0],
           "巽": [0, 1, 1], "坎": [0, 1, 0], "艮": [0, 0, 1], "坤": [0, 0, 0]}

# 六十四卦：卦名 -> (上卦, 下卦)
HEX = {
    "乾为天": ("乾", "乾"), "天泽履": ("乾", "兑"), "天火同人": ("乾", "离"), "天雷无妄": ("乾", "震"),
    "天风姤": ("乾", "巽"), "天水讼": ("乾", "坎"), "天山遁": ("乾", "艮"), "天地否": ("乾", "坤"),
    "泽天夬": ("兑", "乾"), "兑为泽": ("兑", "兑"), "泽火革": ("兑", "离"), "泽雷随": ("兑", "震"),
    "泽风大过": ("兑", "巽"), "泽水困": ("兑", "坎"), "泽山咸": ("兑", "艮"), "泽地萃": ("兑", "坤"),
    "火天大有": ("离", "乾"), "火泽睽": ("离", "兑"), "离为火": ("离", "离"), "火雷噬嗑": ("离", "震"),
    "火风鼎": ("离", "巽"), "火水未济": ("离", "坎"), "火山旅": ("离", "艮"), "火地晋": ("离", "坤"),
    "雷天大壮": ("震", "乾"), "雷泽归妹": ("震", "兑"), "雷火丰": ("震", "离"), "震为雷": ("震", "震"),
    "雷风恒": ("震", "巽"), "雷水解": ("震", "坎"), "雷山小过": ("震", "艮"), "雷地豫": ("震", "坤"),
    "风天小畜": ("巽", "乾"), "风泽中孚": ("巽", "兑"), "风火家人": ("巽", "离"), "风雷益": ("巽", "震"),
    "巽为风": ("巽", "巽"), "风水涣": ("巽", "坎"), "风山渐": ("巽", "艮"), "风地观": ("巽", "坤"),
    "水天需": ("坎", "乾"), "水泽节": ("坎", "兑"), "水火既济": ("坎", "离"), "水雷屯": ("坎", "震"),
    "水风井": ("坎", "巽"), "坎为水": ("坎", "坎"), "水山蹇": ("坎", "艮"), "水地比": ("坎", "坤"),
    "山天大畜": ("艮", "乾"), "山泽损": ("艮", "兑"), "山火贲": ("艮", "离"), "山雷颐": ("艮", "震"),
    "山风蛊": ("艮", "巽"), "山水蒙": ("艮", "坎"), "艮为山": ("艮", "艮"), "山地剥": ("艮", "坤"),
    "地天泰": ("坤", "乾"), "地泽临": ("坤", "兑"), "地火明夷": ("坤", "离"), "地雷复": ("坤", "震"),
    "地风升": ("坤", "巽"), "地水师": ("坤", "坎"), "地山谦": ("坤", "艮"), "坤为地": ("坤", "坤"),
}

LIUSHEN = ["青龙", "朱雀", "勾陈", "螣蛇", "白虎", "玄武"]
LIUSHEN_START = {"甲乙": "青龙", "丙丁": "朱雀", "戊": "勾陈", "己": "螣蛇", "庚辛": "白虎", "壬癸": "玄武"}

WX_SHENG = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}
WX_KE = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}

# 六冲卦（10个）：八纯 + 天雷无妄 + 雷天大壮
LIUCHONG_HEX = {"乾为天", "坤为地", "坎为水", "离为火", "震为雷", "艮为山", "巽为风", "兑为泽",
                "天雷无妄", "雷天大壮"}
# 六合卦（8个）
LIUHE_HEX = {"天地否", "地天泰", "水泽节", "泽水困", "火山旅", "山火贲", "地雷复", "雷地豫"}

# 进神（同五行顺进）/ 退神（逆）
JIN_SHEN = {"寅": "卯", "巳": "午", "申": "酉", "亥": "子", "丑": "辰", "辰": "未", "未": "戌", "戌": "丑"}
TUI_SHEN = {v: k for k, v in JIN_SHEN.items()}

LIUQIN_NAMES = {"父母": "父母", "兄弟": "兄弟", "子孙": "子孙", "妻财": "妻财", "官鬼": "官鬼"}


# ---------------------------------------------------------------- 核心算法

def ganzhi_index(gz):
    """'庚申' -> (天干序号, 地支序号)"""
    gz = gz.strip()
    if len(gz) != 2:
        raise ValueError(f"干支格式错误: {gz}")
    g, z = gz[0], gz[1]
    if g not in GAN or z not in ZHI:
        raise ValueError(f"干支格式错误: {gz}")
    return GAN.index(g), ZHI.index(z)


def xunkong(day_ganzhi):
    """日柱 -> (旬名, 旬首, 空亡两地支)"""
    gi, zi = ganzhi_index(day_ganzhi)
    shou_z = (zi - gi) % 12          # 旬首甲日的地支
    shou = "甲" + ZHI[shou_z]
    kong1 = ZHI[(shou_z + 10) % 12]
    kong2 = ZHI[(shou_z + 11) % 12]
    return shou, f"{kong1}{kong2}空"


def liu_qin(wx_wo, wx_yao):
    """以本宫五行为我，定爻五行之六亲"""
    if wx_yao == wx_wo:
        return "兄弟"
    if WX_SHENG[wx_wo] == wx_yao:
        return "子孙"
    if WX_SHENG[wx_yao] == wx_wo:
        return "父母"
    if WX_KE[wx_wo] == wx_yao:
        return "妻财"
    return "官鬼"


def na_jia(shang, xia):
    """上卦+下卦 -> 六爻干支列表（初→上）"""
    return BAGUA[xia]["nei"] + BAGUA[shang]["wai"]


def shi_ying_and_gong(shang, xia):
    """
    返回 (世爻位置1-6, 应爻位置1-6, 卦宫, 卦型标签)
    歌诀：天同二世天变五，地同四世地变初，人同游魂世居四，人变归魂世在三，全同六世全变三。
    """
    up, lo = GUA_YAO[shang], GUA_YAO[xia]
    t_same = (up[2] == lo[2])   # 天爻：上卦上爻 vs 下卦上爻
    r_same = (up[1] == lo[1])   # 人爻：上卦中爻 vs 下卦中爻
    d_same = (up[0] == lo[0])   # 地爻：上卦下爻 vs 下卦下爻

    def only(cond):
        return bool(cond)

    if t_same and r_same and d_same:
        shi, label = 6, "本宫八纯卦"
    elif (not t_same) and (not r_same) and (not d_same):
        shi, label = 3, "三世卦"
    elif only(t_same) and not r_same and not d_same:
        shi, label = 2, "二世卦"
    elif only(d_same) and not t_same and not r_same:
        shi, label = 4, "四世卦"
    elif only(r_same) and not t_same and not d_same:
        shi, label = 4, "游魂卦"
    elif only(not r_same) and t_same and d_same:
        shi, label = 3, "归魂卦"
    elif only(not t_same) and r_same and d_same:
        shi, label = 5, "五世卦"
    else:  # 地变only
        shi, label = 1, "一世卦"

    # 卦宫
    if label == "归魂卦":
        gong = xia
    elif shi in (4, 5):
        gong = FAN[xia]
    else:
        gong = shang

    # 应爻：世隔两位（初对四、二对五、三对上）
    ying = {1: 4, 2: 5, 3: 6, 4: 1, 5: 2, 6: 3}[shi]
    return shi, ying, gong, label


def liu_shen_list(day_gan):
    """日干 -> 初爻起的六神序列"""
    for key, start in LIUSHEN_START.items():
        if day_gan in key:
            i = LIUSHEN.index(start)
            return [LIUSHEN[(i + k) % 6] for k in range(6)]
    raise ValueError(f"日干无效: {day_gan}")


def yang_yin(gan_zhi):
    """干支 -> 阴阳（阳干配阳支为阳爻……按地支阴阳即可）"""
    return ZHI_YAO_YINYANG[gan_zhi[1]]


def parse_throws(throws):
    """六次摇卦结果(自下而上) -> (本卦名, 变卦名, 动爻位置列表)"""
    if len(throws) != 6:
        raise ValueError("必须输入六次摇卦结果")
    valid = {"少阳", "少阴", "老阳", "老阴"}
    for t in throws:
        if t not in valid:
            raise ValueError(f"无效的摇卦结果: {t}，可用: 少阳/少阴/老阳/老阴")
    ben_yao = []
    bian_yao = []
    dong = []
    for i, t in enumerate(throws):
        if t == "少阳":
            ben_yao.append(1)
            bian_yao.append(1)
        elif t == "少阴":
            ben_yao.append(0)
            bian_yao.append(0)
        elif t == "老阳":   # 阳动变阴
            ben_yao.append(1)
            bian_yao.append(0)
            dong.append(i + 1)
        else:               # 老阴 阴动变阳
            ben_yao.append(0)
            bian_yao.append(1)
            dong.append(i + 1)
    ben = gua_name_from_yao(ben_yao)
    bian = gua_name_from_yao(bian_yao)
    return ben, bian, dong


def gua_name_from_yao(yao):
    """六爻(自下而上) -> 卦名"""
    lo, up = yao[:3], yao[3:]
    xia = next(k for k, v in GUA_YAO.items() if v == lo)
    shang = next(k for k, v in GUA_YAO.items() if v == up)
    for name, (s, x) in HEX.items():
        if s == shang and x == xia:
            return name
    raise ValueError("无法识别卦象")


def build_paipan(hex_name, bian_name=None, day=None, month=None):
    """主排盘。返回字典。"""
    if hex_name not in HEX:
        raise ValueError(f"未知卦名: {hex_name}")
    shang, xia = HEX[hex_name]
    ganzhi_list = na_jia(shang, xia)
    shi, ying, gong, label = shi_ying_and_gong(shang, xia)
    wo = BAGUA[gong]["wx"]

    lines = []
    for i in range(6):  # 初->上
        gz = ganzhi_list[i]
        zhi = gz[1]
        lines.append({
            "pos": i + 1,
            "ganzhi": gz,
            "zhi": zhi,
            "wx": ZHI_WX[zhi],
            "liuqin": liu_qin(wo, ZHI_WX[zhi]),
            "shi": (i + 1 == shi),
            "ying": (i + 1 == ying),
            "dong": False,
            "bian": None,
        })

    dong_list = []
    if bian_name:
        if bian_name not in HEX:
            raise ValueError(f"未知变卦名: {bian_name}")
        b_shang, b_xia = HEX[bian_name]
        b_ganzhi = na_jia(b_shang, b_xia)
        ben_yao = GUA_YAO[xia] + GUA_YAO[shang]
        bian_yao = GUA_YAO[b_xia] + GUA_YAO[b_shang]
        # 找动爻：按卦象阴阳变化定（动爻变出之干支取变卦同位干支，静爻保持本卦干支）
        for i in range(6):
            if ben_yao[i] != bian_yao[i]:
                lines[i]["dong"] = True
                lines[i]["bian"] = b_ganzhi[i]
                dong_list.append(i + 1)
        if not dong_list:
            raise ValueError("本卦与变卦一致：若非静卦请核对卦名（变卦应含动爻变化）")

    # 六神（按日干）
    shen_list = None
    if day:
        shen_list = liu_shen_list(day[0])
        for i in range(6):
            lines[i]["shen"] = shen_list[i]
    else:
        for i in range(6):
            lines[i]["shen"] = None

    # 旬空 / 月破 / 日冲
    kong = None
    if day:
        shou, kong = xunkong(day)
    for ln in lines:
        ln["month_po"] = month is not None and LIUCHONG[ln["zhi"]] == month
        ln["day_chong"] = day is not None and LIUCHONG[ln["zhi"]] == day[1]
        ln["kong"] = kong is not None and ln["zhi"] in kong.replace("空", "")

    # 伏神提示：本卦缺某六亲 -> 本宫八纯卦对应位置
    gong_ganzhi = na_jia(gong, gong)  # 本宫八纯卦六爻
    present = {ln["liuqin"] for ln in lines}
    fushen = []
    for qin in ["父母", "兄弟", "子孙", "妻财", "官鬼"]:
        if qin not in present:
            idx = None
            for i, gz in enumerate(gong_ganzhi):
                if liu_qin(wo, ZHI_WX[gz[1]]) == qin:
                    idx = i
                    break
            if idx is not None:
                fz = gong_ganzhi[idx]
                fly = lines[idx]
                fushen.append(f"{qin}{fz[1]}木" if False else f"{qin}伏神{fz}伏于{['初','二','三','四','五','上'][idx]}爻{fly['ganzhi']}{fly['liuqin']}之下")

    # 动变状态补全：进神/退神/伏吟/爻反吟/回头生克
    for ln in lines:
        if ln["dong"] and ln["bian"]:
            bz, zz = ln["zhi"], ln["bian"][1]
            bwx, zwx = ZHI_WX[bz], ZHI_WX[zz]
            if bz == zz:
                ln["dong_state"] = "伏吟"
            elif LIUCHONG[bz] == zz:
                ln["dong_state"] = "爻反吟"
            elif JIN_SHEN.get(bz) == zz:
                ln["dong_state"] = "化进神"
            elif TUI_SHEN.get(bz) == zz:
                ln["dong_state"] = "化退神"
            elif bwx == zwx:
                ln["dong_state"] = f"化{zwx}（非进退）"
            elif WX_SHENG[zwx] == bwx:
                ln["dong_state"] = "回头生"
            elif WX_KE[zwx] == bwx:
                ln["dong_state"] = "回头克"
            else:
                ln["dong_state"] = None
        else:
            ln["dong_state"] = None

    # 卦反吟：变卦与本卦六冲（上下卦皆冲）
    fan_yin = False
    if bian_name:
        b_s, b_x = HEX[bian_name]
        fan_yin = (FAN[shang] == b_s and FAN[xia] == b_x)

    return {
        "hex": hex_name, "bian": bian_name, "shang": shang, "xia": xia,
        "gong": gong, "wo": wo, "label": label, "shi": shi, "ying": ying,
        "lines": lines, "dong_list": dong_list, "kong": kong,
        "month": month, "day": day, "fushen": fushen, "fan_yin": fan_yin,
    }


# ---------------------------------------------------------------- 输出

POS_NAME = ["", "初爻", "二爻", "三爻", "四爻", "五爻", "上爻"]


def fmt_gz(gz, wx):
    return f"{gz} {wx}"


def print_paipan(p, verbose=False):
    print("=" * 58)
    print(f"本卦：{p['hex']}（{p['gong']}宫·{p['label']}，{p['shang']}{p['xia']}）"
          + (f"　之　{p['bian']}" if p["bian"] else "　（静卦）"))
    print(f"卦宫五行：{p['gong']}属{p['wo']}（以{p['wo']}为我定六亲）")
    print(f"世爻：{POS_NAME[p['shi']]}（我）　应爻：{POS_NAME[p['ying']]}（对方/事）")
    if p["month"]:
        print(f"月建：{p['month']}（{ZHI_WX[p['month']]}）　", end="")
    if p["day"]:
        print(f"日辰：{p['day']}（{ZHI_WX[p['day'][1]]}）　", end="")
    if p["kong"]:
        print(f"旬空：{p['kong']}", end="")
    print()
    print("-" * 58)
    head = f"{'六神':<4}{'爻位':<5}{'干支':<6}{'六亲':<4}{'世应':<4}{'状态'}"
    print(head)
    for ln in reversed(p["lines"]):
        shen = ln["shen"] if ln["shen"] else "-"
        se = ("世" if ln["shi"] else "") + ("应" if ln["ying"] else "")
        state = []
        if ln["dong"]:
            state.append(f"动→{ln['bian']}" + (f"({ln['dong_state']})" if ln["dong_state"] else ""))
        if ln["month_po"]:
            state.append("月破")
        if ln["day_chong"]:
            state.append("日冲(判暗动/日破)")
        if ln["kong"]:
            state.append("旬空")
        st = "、".join(state) if state else ""
        print(f"{shen:<4}{POS_NAME[ln['pos']]:<5}{ln['ganzhi']:<6}{ln['liuqin']:<4}{se:<4}{st}")
    print("-" * 58)
    tags = []
    if p["hex"] in LIUCHONG_HEX:
        tags.append("六冲卦")
    if p["hex"] in LIUHE_HEX:
        tags.append("六合卦")
    if p["label"] in ("游魂卦",):
        tags.append("游魂卦(游移不定)")
    if p["label"] in ("归魂卦",):
        tags.append("归魂卦(归来安定)")
    if p["fan_yin"]:
        tags.append("卦反吟(反复)")
    if tags:
        print("格局提示：" + "；".join(tags))
    if p["dong_list"]:
        print(f"动爻：{', '.join(POS_NAME[i] for i in p['dong_list'])}")
    else:
        print("无动爻（静卦，看日月建与世应旺衰）")
    if p["fushen"]:
        print("伏神提示：")
        for f in p["fushen"]:
            print("　" + f)
    print("=" * 58)


def main():
    ap = argparse.ArgumentParser(description="六爻排盘器")
    ap.add_argument("--throws", nargs="+", help="六次摇卦结果，自下而上（少阳/少阴/老阳/老阴）")
    ap.add_argument("--hexagram", help="本卦名（如 泽山咸）")
    ap.add_argument("--bian", help="变卦名（如 泽地萃）；无动爻可省略")
    ap.add_argument("--day", help="日柱干支（如 庚申），用于六神与旬空")
    ap.add_argument("--month", help="月建地支（如 卯），用于月破")
    args = ap.parse_args()

    try:
        if args.throws:
            ben, bian, dong = parse_throws(args.throws)
            if not dong:
                bian = None
            print(f"（据六次摇卦识别：本卦 {ben}，动爻 {dong or '无'}）")
            p = build_paipan(ben, bian, args.day, args.month)
        elif args.hexagram:
            p = build_paipan(args.hexagram, args.bian, args.day, args.month)
        else:
            ap.error("必须提供 --throws 或 --hexagram")
        print_paipan(p)
    except ValueError as e:
        print(f"错误：{e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
